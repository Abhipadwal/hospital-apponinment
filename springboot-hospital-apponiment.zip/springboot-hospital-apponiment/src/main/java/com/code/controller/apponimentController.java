package com.code.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.entity.Apponiment;
import com.code.service.ApponimentService;

@RestController
@RequestMapping("aapi")
public class apponimentController {

	@Autowired
	ApponimentService apponimentService;

	@PostMapping("appointments")
	public Apponiment createApponiment(@RequestBody Apponiment apponiment) {
		return apponimentService.createApponiment(apponiment);
	}

	@GetMapping("appointments")
	public List<Apponiment> getAll() {
		return apponimentService.getAllApponiment();
	}

	@GetMapping("appointments/{id}")
	public Apponiment getApponimnetById(@PathVariable int id) {
		return apponimentService.getApponiment(id);
	}

	@DeleteMapping("appointments/{id}")
	public void deleteAppnimnet(@PathVariable int id) {
		apponimentService.cancleApponiment(id);
	}


	@GetMapping("appointments/search/{doctorId}/{patientId}/{startDate}")
	public List<Apponiment> search(
			@PathVariable("doctorId") int doctorId, 
			@PathVariable("patientId")int patientId, 
			@PathVariable("startDate") LocalDateTime startDate ){
		System.out.println(startDate);
		return apponimentService.search(doctorId, patientId, startDate);
	}
}
