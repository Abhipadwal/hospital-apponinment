package com.code.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.code.entity.Apponiment;

@Repository
public interface ApponimentRepository extends JpaRepository<Apponiment, Integer>{

	List<Apponiment> findByDoctorIdAndPatientIdAndStartDate(
			int doctorId, 
			int patientId, 
			LocalDateTime startDate);
}
