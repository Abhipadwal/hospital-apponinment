package com.code.exception;

import java.util.Date;

public class ErrorDetail {

	private Date timeStampe;
	private String details;
	private String message;
	public ErrorDetail(Date timeStampe, String details, String message) {
		super();
		this.timeStampe = timeStampe;
		this.details = details;
		this.message = message;
	}
	public ErrorDetail() {
		super();
	}
	public Date getTimeStampe() {
		return timeStampe;
	}
	public void setTimeStampe(Date timeStampe) {
		this.timeStampe = timeStampe;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
