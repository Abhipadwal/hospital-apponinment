package com.code.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.entity.Apponiment;
import com.code.repository.ApponimentRepository;

@Service
public class ApponimentService {

	@Autowired
	ApponimentRepository apponimentRepo;

	public Apponiment getApponiment(int id) {
		return apponimentRepo.findById(id).orElse(null);
	}
	
	public List<Apponiment> getAllApponiment() {
		return apponimentRepo.findAll();
	}

	public Apponiment createApponiment(Apponiment apponiment) {
		return apponimentRepo.save(apponiment);
	}

	public void cancleApponiment(int id) {
		apponimentRepo.deleteById(id);
	}
	
	public List<Apponiment> search(int doctorId, int patientId, LocalDateTime startDate){
		return apponimentRepo.findByDoctorIdAndPatientIdAndStartDate(doctorId, patientId, startDate);
	}
}
